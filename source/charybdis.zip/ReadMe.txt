T E P I D   M O N K E Y   F O N T S
freeware fonts for a freeware world

Site:   http://www.fontframe.com/tepidmonkey
E-mail: tepidmonkey@yahoo.com

Thanks for your interest in my fonts!

For help on how to unzip, unstuff or install one of my 
fonts, please visit my site at 
http://www.fontframe.com/tepidmonkey and go to the Help section.
If you have any comments or questions, you can e-mail 
me at tepidmonkey@yahoo.com and I'll try to reply as 
soon as possible.

Every week, I present a brand new original font for 
your downloading pleasure, so be sure to visit my web 
site every Sunday.

You may use this font(s) for non-commercial and 
commercial purposes. You are not allowed to sell this 
font for any fee at all. You are allowed to 
redistribute it as long as you don't charge ANYTHING 
for it (at all) and if you include this unaltered 
Read Me file. You may not change any aspect of the font 
file or this file.
For the full set of terms of use (which override what 
is listed here), go to http://www.fontframe.com/tepidmonkey 
and visit the Terms Of Use section.